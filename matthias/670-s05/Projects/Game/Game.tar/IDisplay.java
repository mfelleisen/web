interface IDisplay {

    // update the sum field 
    void sumDisplay(int s); 

    // update the message field 
    void msgDisplay(String s); 
}
